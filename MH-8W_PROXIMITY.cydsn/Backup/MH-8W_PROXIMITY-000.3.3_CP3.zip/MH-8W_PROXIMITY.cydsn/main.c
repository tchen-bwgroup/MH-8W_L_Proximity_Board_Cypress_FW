/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

//#define RUN_TUNER                   1

#define ROW_NUM                     255
#define ROW_SIZE                    64

#define EEPROM_SIGNATURE_0          0x55
#define EEPROM_SIGNATURE_1          0xAA

#define BASELINE                    15000  //MH-8W Prototype-2

#define WDT_PERIOD                  (150 * 40)

static const uint8 CYCODE eepStrg[ROW_SIZE]  __attribute__ ((section (".EEPROMDATA"))) = {0,0,0};

uint8   bRAMarray[ROW_SIZE];
uint16  wDefaultBaseline = 0;

uint8   bActiveCount = 255;
uint8   bStatus;

#define WRITE                          0x61

uint8   bI2C_Reg[7];
#define I2C_COMMAND                     0
#define I2C_DATA_MSB                    1
#define I2C_DATA_LSB                    2

#define I2C_CURRENT_RAW_COUNT_MSB       3
#define I2C_CURRENT_RAW_COUNT_LSB       4
#define I2C_THRESHOLD_COUNT_MSB         5
#define I2C_THRESHOLD_COUNT_LSB         6


unsigned char bPowerOnCheckTh = 1;


CY_ISR(WDT_ISR)
{
    /* Clear WDT interrupt */
    CySysWdtClearInterrupt();
	   
    /* Write WDT_MATCH with current match value + desired match value */
    CySysWdtWriteMatch((uint16)CySysWdtReadMatch()+WDT_PERIOD);
    
    bActiveCount++;
}

void EEPROM_Write(void)
{
    CySysFlashWriteRow(ROW_NUM, bRAMarray);
    CyDelay(100);
}

void EEPROM_Start(void)
{
    uint8 bCount;
    
    for(bCount=0;bCount<ROW_SIZE;bCount++){
        bRAMarray[bCount] = eepStrg[bCount];
    }
    
    wDefaultBaseline = bRAMarray[2];
    wDefaultBaseline = wDefaultBaseline << 8;
    wDefaultBaseline = wDefaultBaseline & 0xFF00;
    wDefaultBaseline += bRAMarray[3];
    
    if( (bRAMarray[0] != EEPROM_SIGNATURE_0) || (bRAMarray[1] != EEPROM_SIGNATURE_1) )
    {
        bRAMarray[0] = EEPROM_SIGNATURE_0;
        bRAMarray[1] = EEPROM_SIGNATURE_1;
        
        wDefaultBaseline = BASELINE;
        
        bRAMarray[2] = wDefaultBaseline >> 8;
        bRAMarray[3] = wDefaultBaseline & 0xFF;
        
        EEPROM_Write();
    }
    
    bI2C_Reg[I2C_THRESHOLD_COUNT_MSB] = wDefaultBaseline >> 8;
    bI2C_Reg[I2C_THRESHOLD_COUNT_LSB] = wDefaultBaseline & 0xFF;
}

void WDT_Start()
{
    /* Enable global interrupts before starting CapSense and EzI2C blocks*/
    /* Write WDT_MATCH with the desired match value */
    CySysWdtWriteMatch(WDT_PERIOD);
     
     /* Mask WDT interrupt to be available for CPU service */
    CySysWdtUnmaskInterrupt();
     
     /* Set the WDT interrupt vector to the WDT ISR*/
    CyIntSetVector(4, WDT_ISR);
     
    /* Enable WDT ISR in CPU vectors - which is caused by WDT match */
    CyIntEnable(4);   
}

void CapSense_Tuner(void)
{
    EZI2C_Start();	 		/* Initialize EZI2C block */
    /* Make CapSense RAM data structure an I2C buffer, to use CapSense Tuner */
    EZI2C_EzI2CSetBuffer1(sizeof(CapSense_dsRam), sizeof(CapSense_dsRam), (uint8 *)&CapSense_dsRam);
 
    CapSense_Start();		     /* Initialize CapSense Component */	
    CapSense_ScanAllWidgets();   /* Scan all widgets */
    
    for(;;)
    {
        if(CapSense_NOT_BUSY == CapSense_IsBusy())
        {   
            CapSense_ProcessAllWidgets();   /* Process data for all widgets */
            
            if (CapSense_IsWidgetActive(CapSense_PROXIMITY0_WDGT_ID))
            {
                Pin_interrupt_Write(1);
            }
            else
            {
                Pin_interrupt_Write(0);   
            }
                        
            /* Sync CapSense parameters with those set via CapSense tuner before 
             * the beginning of new CapSense scan */
            CapSense_RunTuner();

            /* Initiate new scan for all widgets */
            CapSense_ScanAllWidgets();                      
        }
        
    }
}





int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    EEPROM_Start();
    WDT_Start();
    
    #ifdef RUN_TUNER
        CapSense_Tuner();
    #endif
    
    CapSense_Start();		     // Initialize CapSense Component 
    
    EZI2C_Start();	 		
    EZI2C_EzI2CSetBuffer1(sizeof(bI2C_Reg), sizeof(bI2C_Reg) , (uint8 *)&bI2C_Reg);
    
    for(;;)
    {
        
        if( (EZI2C_EzI2CGetActivity() & EZI2C_EZI2C_STATUS_BUSY) == 0)
        {
            if(bI2C_Reg[I2C_COMMAND] == WRITE)
            {
                           
                bRAMarray[2] = bI2C_Reg[I2C_DATA_MSB];
                bRAMarray[3] = bI2C_Reg[I2C_DATA_LSB];
                
                wDefaultBaseline = bRAMarray[2];
                wDefaultBaseline = wDefaultBaseline << 8;
                wDefaultBaseline = wDefaultBaseline & 0xFF00;
                wDefaultBaseline += bRAMarray[3];
            
                EEPROM_Write();
                
                bI2C_Reg[I2C_COMMAND]  = 0;
                bI2C_Reg[I2C_DATA_MSB] = 0;
                bI2C_Reg[I2C_DATA_LSB] = 0;
             
                bI2C_Reg[I2C_THRESHOLD_COUNT_MSB] =  bRAMarray[2];
                bI2C_Reg[I2C_THRESHOLD_COUNT_LSB] =  bRAMarray[3];
            }
        }
        
        if(bActiveCount)
        {
            bActiveCount--;
            
            CapSense_ScanAllWidgets();      /* Scan all widgets */
            while(CapSense_NOT_BUSY != CapSense_IsBusy())
            {
                CySysPmSleep();   
            }
            CapSense_ProcessAllWidgets();   /* Process data for all widgets */
            
            CapSense_IsWidgetActive(CapSense_PROXIMITY0_WDGT_ID);
            
            bI2C_Reg[I2C_CURRENT_RAW_COUNT_MSB] = (CapSense_dsRam.snsList.proximity0[CapSense_PROXIMITY0_WDGT_ID].raw[0] >> 8);
            bI2C_Reg[I2C_CURRENT_RAW_COUNT_LSB] = (CapSense_dsRam.snsList.proximity0[CapSense_PROXIMITY0_WDGT_ID].raw[0] & 0xFF); 
            
            if(CapSense_dsRam.snsList.proximity0[CapSense_PROXIMITY0_WDGT_ID].raw[0] >= wDefaultBaseline)
            {
                Pin_interrupt_Write(1);
            }
            else
            {
                Pin_interrupt_Write(0);
            }
            
            /*
            if(CapSense_IsWidgetActive(CapSense_PROXIMITY0_WDGT_ID))
            {
                //Pin_interrupt_Write(1);
            }
            else
            {
                if(bPowerOnCheckTh == 1)
                {
                    if(CapSense_dsRam.snsList.proximity0[CapSense_PROXIMITY0_WDGT_ID].raw[0] >= wDefaultBaseline)
                    {
                        Pin_interrupt_Write(1);
                    }
                    else
                    {
                        bPowerOnCheckTh = 0;    
                    }
                }
                else
                {
                    Pin_interrupt_Write(0);
                }
            }
            
            //bI2C_Reg[I2C_CURRENT_RAW_COUNT_MSB] = (CapSense_dsRam.snsList.proximity0[CapSense_PROXIMITY0_WDGT_ID].raw[0] >> 8);
            //bI2C_Reg[I2C_CURRENT_RAW_COUNT_LSB] = (CapSense_dsRam.snsList.proximity0[CapSense_PROXIMITY0_WDGT_ID].raw[0] & 0xFF); 
            */
            
            /*
            if( (CapSense_dsRam.snsList.proximity0[CapSense_PROXIMITY0_WDGT_ID].diff >= 10) && (CapSense_dsRam.snsList.proximity0[CapSense_PROXIMITY0_WDGT_ID].raw[0] < wDefaultBaseline))
            {
                bActiveCount = 1u;
            }
            */
        }
        else
        {
            uint8 intState = CyEnterCriticalSection();
            
            bStatus = (EZI2C_EzI2CGetActivity() & EZI2C_EZI2C_STATUS_BUSY);
            
            if (0u == bStatus)
            {
                EZI2C_Sleep();
                CySysPmDeepSleep();  
                CyExitCriticalSection(intState);
                EZI2C_Wakeup();
            }

            else
            {
                //bActiveCount = 255;  
                bActiveCount = 10; 
                CyExitCriticalSection(intState);   
            }
        }
    }
}

/* [] END OF FILE */
